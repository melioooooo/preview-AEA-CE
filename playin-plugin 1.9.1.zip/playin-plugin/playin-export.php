<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * IDE SILENCING
 * These definitions only exist to stop the IDE from reporting "unknown function" errors.
 * They will never be executed because of the if (false) condition.
 */
if (false) {
    function add_submenu_page($parent_slug, $page_title, $menu_title, $capability, $menu_slug, $callback = '')
    {
    }
    function submit_button($text = null, $type = 'primary', $name = 'submit', $wrap = true, $other_attributes = null)
    {
    }
    function current_user_can($capability, ...$args)
    {
        return true;
    }
    function get_post_meta($post_id, $key = '', $single = false)
    {
        return '';
    }
    function add_action($tag, $callback, $priority = 10, $accepted_args = 1)
    {
    }
    function get_current_screen()
    {
        return (object) array('post_type' => 'registration');
    }
    function admin_url($path = '', $scheme = 'admin')
    {
        return '';
    }
    function esc_url($url, $protocols = null, $_context = 'display')
    {
        return $url;
    }

    // Fix for "Trying to get property of non-object" on $post->ID
    // By defining get_posts to return an array of objects
    class WP_Post
    {
        public $ID;
        public $post_title;
        public $post_date;
    }
    function get_posts($args = null)
    {
        return array(new WP_Post());
    }
}

// Add submenu to the "Inscriptions" menu
function playin_register_export_submenu()
{
    add_submenu_page(
        'edit.php?post_type=registration', // Parent slug (Registration CPT)
        'Export CSV',                      // Page title
        'Export CSV',                      // Menu title
        'manage_options',                  // Capability
        'playin-export-csv',               // Menu slug
        'playin_render_export_page'        // Callback function
    );
}
add_action('admin_menu', 'playin_register_export_submenu');

// Add "Export CSV" button to the post list table
function playin_add_export_button_to_list()
{
    $screen = get_current_screen();
    if (isset($screen->post_type) && $screen->post_type === 'registration') {
        $export_url = admin_url('admin.php?action=playin_download_csv');
        echo '<a href="' . esc_url($export_url) . '" class="page-title-action">Export CSV</a>';
    }
}
add_action('all_admin_notices', function () {
    // We hack into all_admin_notices to output the button near the top, 
    // or we can use `views_edit-registration` to put it in the list views.
    // Let's use a JS snippet to append it to the title action area for best visibility
    $screen = get_current_screen();
    if (isset($screen->post_type) && $screen->post_type === 'registration') {
        $export_url = admin_url('admin.php?action=playin_download_csv');
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                $('.wrap .page-title-action').after('<a href="<?php echo $export_url; ?>" class="page-title-action" style="margin-left: 10px;">Exporter CSV</a>');
            });
        </script>
        <?php
    }
});


// Render the export page
function playin_render_export_page()
{
    ?>
    <div class="wrap">
        <h1>Exporter les Inscriptions</h1>
        <p>Cliquez sur le bouton ci-dessous pour télécharger un fichier CSV contenant toutes les inscriptions.</p>
        <form method="post" action="<?php echo admin_url('admin.php'); ?>">
            <input type="hidden" name="action" value="playin_download_csv">
            <?php submit_button('Télécharger CSV'); ?>
        </form>
    </div>
    <?php
}

// Handle the CSV download
function playin_handle_csv_download()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    // Clean buffer
    if (ob_get_length())
        ob_end_clean();

    // Set headers for download
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=registrations_' . date('Y-m-d') . '.csv');

    // Open output stream
    $output = fopen('php://output', 'w');

    // Add BOM for Excel compatibility
    fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

    // Add CSV headers
    fputcsv($output, array('ID', 'Nom', 'Email', 'Ville', 'EA ID', 'Discord', 'Téléphone', 'Date de Naissance', 'Date Inscription'));

    // Fetch all registrations
    $args = array(
        'post_type' => 'registration',
        'posts_per_page' => -1,
        'post_status' => 'any',
    );
    $registrations = get_posts($args);

    foreach ($registrations as $post) {
        $post_id = $post->ID;
        $city = get_post_meta($post_id, 'registration_city', true);
        $title = $post->post_title;

        // Attempt to extract name from title "Name - City"
        $name = $title;
        if ($city && strpos($title, ' - ' . $city) !== false) {
            $name = str_replace(' - ' . $city, '', $title);
        }

        fputcsv($output, array(
            $post_id,
            $name,
            get_post_meta($post_id, 'registration_email', true),
            $city,
            get_post_meta($post_id, 'registration_eaid', true),
            get_post_meta($post_id, 'registration_discord', true),
            get_post_meta($post_id, 'registration_phone', true),
            get_post_meta($post_id, 'registration_birthdate', true),
            $post->post_date
        ));
    }

    fclose($output);
    exit;
}
add_action('admin_post_playin_download_csv', 'playin_handle_csv_download');
// Also handle the legacy POST if coming from the submenu page specific form
if (isset($_POST['playin_action']) && $_POST['playin_action'] == 'download_csv') {
    add_action('admin_init', 'playin_handle_csv_download');
}
